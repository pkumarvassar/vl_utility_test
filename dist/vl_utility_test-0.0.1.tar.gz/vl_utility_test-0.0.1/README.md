# VL_UTILITY_TEST

Testing of python package module 
## Instructions

1. Install:

```
pip install vl-utility-test
```

## Description
- Craeting tiles using raaster files
- Merging small-small tiles 
- Craetion of differenet band 
- Vectorization of raster for visualisation of target region


