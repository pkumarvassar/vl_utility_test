import math

def addition(x,y):
    return x+y

def subtraction(x,y):
    return x-y

def multiply(x,y):
    return x*y

def division(x,y):
    return x/y

def power(x,y):
    return math.pow(x,y)

def hello():
    print('Hello There VL !!!')



