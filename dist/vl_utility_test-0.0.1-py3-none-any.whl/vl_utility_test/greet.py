
def welcome():
    print("Welcome Geeky user!!! \nThanks for installing(^_^)")
